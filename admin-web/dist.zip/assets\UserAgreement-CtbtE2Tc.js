import{d as y,o as C,c,k as p,l as f,T as _,G as m,s as i,r as u,i as r,b as e,e as D,j as g,t as v,f as b,v as w,_ as T}from"./index-Ba7QOAc-.js";import{b as V}from"./webDialog-Ci2ufuXz.js";const I={class:"agreement-page"},N={class:"page-header"},U={class:"actions"},A=["disabled"],B=["disabled"],S={key:0,class:"spinner"},M={key:0,class:"state-box"},j={key:1,class:"config-card"},E={class:"field"},G={class:"field content-field"},P={class:"preview-card"},q={class:"preview-title"},z={class:"preview-content"},F=y({__name:"UserAgreement",setup(H){const d={title:"弦予音乐用户协议",content:`一、协议范围
本协议适用于弦予音乐客户端账号系统及相关云端同步、资料管理、统计上报、风控安全服务。用户注册、登录或继续使用账号功能，即表示已阅读并同意本协议。

二、账号注册与使用
用户应使用真实、有效的邮箱完成注册，并妥善保管账号、密码和邮箱验证码。因用户主动泄露、共享账号或使用非官方客户端造成的损失，由用户自行承担。

三、本地数据读取说明
为提供账号登录、设备安全识别、播放统计、同步和故障排查功能，账号系统可能读取或生成以下本地数据：本机设备标识、客户端版本、操作系统版本、设备型号、登录状态凭证、用户主动上传的头像、本地收藏、歌单、播放历史、听歌时长等音乐使用数据，以及软件运行错误日志。上述数据仅用于账号服务、安全风控、功能同步、异常定位和产品维护。

四、数据上报与安全
客户端启动、登录、注册、搜索、播放统计、错误反馈等行为可能向服务器上报必要信息，包括设备ID、IP地址、账号ID、客户端版本、操作系统版本、设备型号、行为时间和必要的请求参数。我们将尽合理努力保护数据安全，不会主动出售用户个人信息。

五、禁止行为
用户不得利用账号系统进行恶意攻击、批量注册、刷量、破解、逆向、绕过限制、上传违法违规内容、干扰服务器稳定性或侵犯他人权益。发现异常行为时，平台有权限制、封禁账号或设备。

六、封禁与申诉
若账号或设备因违反协议、安全风控或恶意行为被封禁，登录时将提示封禁状态及原因。用户如认为处理有误，可联系管理员并提供账号、设备ID及相关说明进行核查。

七、协议更新
平台可根据功能调整、安全要求或法律合规需要更新本协议。更新后继续使用账号功能，视为接受更新后的协议内容。`},l=u(!0),n=u(!1),s=u({...d});async function h(){l.value=!0;const a=await m("get_user_agreement_admin");a.code===200&&a.data?s.value={title:String(a.data.title||d.title),content:String(a.data.content||d.content)}:i(a.msg||"加载协议失败"),l.value=!1}async function k(){await V("确定恢复为初版用户协议吗？恢复后需要点击保存才会生效。",{title:"恢复初版协议",confirmText:"确认恢复"})&&(s.value={...d})}async function x(){const a=s.value.title.trim(),t=s.value.content.trim();if(!a){i("协议标题不能为空");return}if(t.length<20){i("协议内容过短");return}n.value=!0;const o=await m("save_user_agreement",{title:a,content:t});n.value=!1,o.code===200?(i("保存成功","success"),s.value={title:a,content:t}):i(o.msg||"保存失败")}return C(h),(a,t)=>(r(),c("div",I,[p(_,{name:"fade-down",appear:""},{default:f(()=>[e("div",N,[t[2]||(t[2]=e("div",null,[e("h2",{class:"page-title"},"用户协议"),e("p",{class:"page-desc"},"配置客户端账号登录、注册页弹窗展示的用户协议。未保存自定义内容时，服务端会下发默认初版协议。")],-1)),e("div",U,[e("button",{class:"btn-secondary",disabled:l.value||n.value,onClick:k},"恢复初版",8,A),e("button",{class:"btn-save",disabled:l.value||n.value,onClick:x},[n.value?(r(),c("span",S)):D("",!0),g(" "+v(n.value?"保存中...":"保存协议"),1)],8,B)])])]),_:1}),p(_,{name:"fade-up",appear:""},{default:f(()=>[l.value?(r(),c("div",M,[...t[3]||(t[3]=[e("span",{class:"loader"},null,-1),g(" 加载中... ",-1)])])):(r(),c("div",j,[e("label",E,[t[4]||(t[4]=e("span",null,"协议标题",-1)),b(e("input",{"onUpdate:modelValue":t[0]||(t[0]=o=>s.value.title=o),type:"text",placeholder:"弦予音乐用户协议"},null,512),[[w,s.value.title]])]),e("label",G,[t[5]||(t[5]=e("span",null,"协议内容",-1)),b(e("textarea",{"onUpdate:modelValue":t[1]||(t[1]=o=>s.value.content=o),placeholder:"请输入用户协议内容"},null,512),[[w,s.value.content]])]),e("div",P,[e("div",q,v(s.value.title||"弦予音乐用户协议"),1),e("div",z,v(s.value.content),1)])]))]),_:1})]))}}),L=T(F,[["__scopeId","data-v-354b3f5c"]]);export{L as default};
