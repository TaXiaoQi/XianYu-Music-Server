function $(t){const o=t;o.style.backdropFilter="none",o.style.setProperty("-webkit-backdrop-filter","none")}function f(){const t=document.createElement("div");return t.className="mobile-dialog-overlay",t}function g(){const t=document.createElement("div");return t.className="mobile-dialog",t}function v(t,o){t.style.opacity="0",o.style.opacity="0",o.style.transform="scale(0.94)",document.body.appendChild(t),t.appendChild(o),t.offsetHeight,t.style.transition="opacity 0.24s cubic-bezier(0.16, 1, 0.3, 1)",o.style.transition="transform 0.24s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.24s",t.style.opacity="1",o.style.opacity="1",o.style.transform="scale(1)"}function k(t){const o=t.querySelector(".mobile-dialog");t.style.setProperty("backdrop-filter","none"),t.style.setProperty("-webkit-backdrop-filter","none"),requestAnimationFrame(()=>{t.style.opacity="0",o&&(o.style.opacity="0",o.style.transform="scale(0.96)"),setTimeout(()=>t.remove(),240)})}function c(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/\n/g,"<br/>")}function q(t,o={}){const{title:d="操作确认",confirmText:i="确认",cancelText:l="取消",danger:u=!1}=o;return new Promise(m=>{const s=f(),n=g(),e=u?"danger":"";n.innerHTML=`
      <div class="mobile-dialog-title">${c(d)}</div>
      <div class="mobile-dialog-body">${c(t)}</div>
      <div class="mobile-dialog-actions">
        <button class="mobile-dialog-btn cancel" type="button">${c(l)}</button>
        <button class="mobile-dialog-btn confirm ${e}" type="button">${c(i)}</button>
      </div>
    `;const a=n.querySelector(".cancel"),p=n.querySelector(".confirm"),b=r=>{k(s),m(r)};a.onclick=()=>b(!1),p.onclick=()=>b(!0),s.onclick=r=>{r.target===s&&b(!1)},v(s,n),setTimeout(()=>p.focus(),100)})}function T(t,o="",d={}){const{title:i="输入",confirmText:l="确定",cancelText:u="取消",placeholder:m=""}=d;return new Promise(s=>{const n=f(),e=g();e.innerHTML=`
      <div class="mobile-dialog-title">${c(i)}</div>
      <div class="mobile-dialog-body">${c(t)}</div>
      <input class="mobile-dialog-input" type="text" value="${c(o)}" placeholder="${c(m)}" />
      <div class="mobile-dialog-actions">
        <button class="mobile-dialog-btn cancel" type="button">${c(u)}</button>
        <button class="mobile-dialog-btn confirm" type="button">${c(l)}</button>
      </div>
    `;const a=e.querySelector(".mobile-dialog-input"),p=e.querySelector(".cancel"),b=e.querySelector(".confirm"),r=y=>{k(n),s(y)};p.onclick=()=>r(null),b.onclick=()=>r(a.value),a.addEventListener("keydown",y=>{y.key==="Enter"&&r(a.value)}),n.onclick=y=>{y.target===n&&r(null)},v(n,e),setTimeout(()=>{a.focus(),a.select()},100)})}function h(t,o){return new Promise(d=>{const i=f(),l=g(),u=o.filter(e=>e.show!==!1).map(e=>`<button class="${e.danger?"action danger":e.success?"action success":"action"}" type="button" data-key="${c(e.key)}">${c(e.label)}</button>`).join("");l.innerHTML=`
      <div class="mobile-dialog-title">${c(t)}</div>
      <div class="mobile-dialog-actions-list">${u}</div>
      <div class="mobile-dialog-actions">
        <button class="mobile-dialog-btn cancel" type="button">取消</button>
      </div>
    `;const m=l.querySelector(".cancel"),s=l.querySelectorAll(".mobile-dialog-actions-list .action"),n=e=>{k(i),d(e)};m.onclick=()=>n(null),s.forEach(e=>{e.addEventListener("click",()=>n(e.dataset.key||null))}),i.onclick=e=>{e.target===i&&n(null)},v(i,l)})}export{q as a,h as b,T as m,$ as r};
