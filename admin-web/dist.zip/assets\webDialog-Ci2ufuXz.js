function f(){const e=document.createElement("div");return e.className="web-dialog-overlay",e}function g(){const e=document.createElement("div");return e.className="web-dialog",e}function p(e,o){document.body.style.overflow="hidden",document.body.appendChild(e),e.appendChild(o),requestAnimationFrame(()=>{e.classList.add("show"),o.classList.add("show")})}function k(e){const o=e.querySelector(".web-dialog");e.classList.remove("show"),o==null||o.classList.remove("show"),setTimeout(()=>{e.remove(),document.querySelector(".web-dialog-overlay")||(document.body.style.overflow="")},240)}function n(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/\n/g,"<br/>")}function E(e,o={}){const{title:b="操作确认",confirmText:d="确认",cancelText:l="取消",danger:m=!0}=o;return new Promise(y=>{const r=f(),c=g(),i=m?"danger":"primary";c.innerHTML=`
      <div class="web-dialog-title">${n(b)}</div>
      <div class="web-dialog-body">${n(e)}</div>
      <div class="web-dialog-actions">
        <button class="web-dialog-btn cancel" type="button">${n(l)}</button>
        <button class="web-dialog-btn confirm ${i}" type="button">${n(d)}</button>
      </div>
    `;const t=c.querySelector(".cancel"),w=c.querySelector(".confirm"),u=a=>{k(r),y(a)};t.onclick=()=>u(!1),w.onclick=()=>u(!0),document.addEventListener("keydown",s);function s(a){a.key==="Escape"?(document.removeEventListener("keydown",s),u(!1)):a.key==="Enter"&&(document.removeEventListener("keydown",s),u(!0))}p(r,c)})}function L(e,o="",b={}){const{title:d="输入",confirmText:l="确定",cancelText:m="取消",placeholder:y=""}=b;return new Promise(r=>{const c=f(),i=g();i.innerHTML=`
      <div class="web-dialog-title">${n(d)}</div>
      <div class="web-dialog-body">${n(e)}</div>
      <input class="web-dialog-input" type="text" value="${n(o)}" placeholder="${n(y)}" />
      <div class="web-dialog-actions">
        <button class="web-dialog-btn cancel" type="button">${n(m)}</button>
        <button class="web-dialog-btn confirm primary" type="button">${n(l)}</button>
      </div>
    `;const t=i.querySelector(".web-dialog-input"),w=i.querySelector(".cancel"),u=i.querySelector(".confirm"),s=v=>{k(c),r(v)};w.onclick=()=>s(null),u.onclick=()=>s(t.value),t.addEventListener("keydown",v=>{v.key==="Enter"&&s(t.value)}),document.addEventListener("keydown",a);function a(v){v.key==="Escape"&&(document.removeEventListener("keydown",a),s(null))}p(c,i),setTimeout(()=>{t.focus(),t.select()},100)})}function $(e,o){return new Promise(b=>{const d=f(),l=g(),m=o.filter(t=>t.show!==!1).map(t=>`<button class="${t.danger?"action danger":t.success?"action success":"action"}" type="button" data-key="${n(t.key)}">${n(t.label)}</button>`).join("");l.innerHTML=`
      <div class="web-dialog-title">${n(e)}</div>
      <div class="web-dialog-actions-list">${m}</div>
      <div class="web-dialog-actions">
        <button class="web-dialog-btn cancel" type="button">取消</button>
      </div>
    `;const y=l.querySelector(".cancel"),r=l.querySelectorAll(".web-dialog-actions-list .action"),c=t=>{k(d),b(t)};y.onclick=()=>c(null),r.forEach(t=>{t.addEventListener("click",()=>c(t.dataset.key||null))}),document.addEventListener("keydown",i);function i(t){t.key==="Escape"&&(document.removeEventListener("keydown",i),c(null))}p(d,l)})}export{L as a,E as b,$ as w};
