import{d as y,o as w,c as d,b as t,F as x,f as v,v as b,t as c,r as u,G as f,s as n,i as m,_ as k}from"./index-Ba7QOAc-.js";import{a as C}from"./mobileDialog-hNrff6fW.js";/* empty css                   */const D={class:"mobile-page"},h={class:"mobile-card mobile-form"},I={key:0,class:"mobile-empty"},M={class:"mobile-field"},U={class:"mobile-field"},A={class:"mobile-actions"},B=["disabled"],S=["disabled"],V={class:"mobile-card"},F={class:"agreement-preview-title"},T={class:"agreement-preview-content"},E=y({__name:"MobileUserAgreement",setup(G){const i={title:"弦予音乐用户协议",content:`一、协议范围
本协议适用于弦予音乐客户端账号系统及相关云端同步、资料管理、统计上报、风控安全服务。用户注册、登录或继续使用账号功能，即表示已阅读并同意本协议。

二、账号注册与使用
用户应使用真实、有效的邮箱完成注册，并妥善保管账号、密码和邮箱验证码。因用户主动泄露、共享账号或使用非官方客户端造成的损失，由用户自行承担。

三、本地数据读取说明
为提供账号登录、设备安全识别、播放统计、同步和故障排查功能，账号系统可能读取或生成以下本地数据：本机设备标识、客户端版本、操作系统版本、设备型号、登录状态凭证、用户主动上传的头像、本地收藏、歌单、播放历史、听歌时长等音乐使用数据，以及软件运行错误日志。上述数据仅用于账号服务、安全风控、功能同步、异常定位和产品维护。

四、数据上报与安全
客户端启动、登录、注册、搜索、播放统计、错误反馈等行为可能向服务器上报必要信息，包括设备ID、IP地址、账号ID、客户端版本、操作系统版本、设备型号、行为时间和必要的请求参数。我们将尽合理努力保护数据安全，不会主动出售用户个人信息。

五、禁止行为
用户不得利用账号系统进行恶意攻击、批量注册、刷量、破解、逆向、绕过限制、上传违法违规内容、干扰服务器稳定性或侵犯他人权益。发现异常行为时，平台有权限制、封禁账号或设备。

六、封禁与申诉
若账号或设备因违反协议、安全风控或恶意行为被封禁，登录时将提示封禁状态及原因。用户如认为处理有误，可联系管理员并提供账号、设备ID及相关说明进行核查。

七、协议更新
平台可根据功能调整、安全要求或法律合规需要更新本协议。更新后继续使用账号功能，视为接受更新后的协议内容。`},r=u(!0),o=u(!1),s=u({...i});async function p(){r.value=!0;const l=await f("get_user_agreement_admin");l.code===200&&l.data?s.value={title:String(l.data.title||i.title),content:String(l.data.content||i.content)}:n(l.msg||"加载协议失败"),r.value=!1}async function _(){await C("确定恢复为初版用户协议吗？恢复后需要点击保存才会生效。")&&(s.value={...i})}async function g(){const l=s.value.title.trim(),e=s.value.content.trim();if(!l)return n("协议标题不能为空");if(e.length<20)return n("协议内容过短");o.value=!0;const a=await f("save_user_agreement",{title:l,content:e});o.value=!1,a.code===200?(n("保存成功","success"),s.value={title:l,content:e}):n(a.msg||"保存失败")}return w(p),(l,e)=>(m(),d("div",D,[t("section",h,[e[4]||(e[4]=t("h3",{class:"mobile-card-title"},"用户协议",-1)),e[5]||(e[5]=t("p",{class:"mobile-muted"},"配置客户端账号登录、注册页弹窗展示的用户协议。",-1)),r.value?(m(),d("div",I,"加载中...")):(m(),d(x,{key:1},[t("label",M,[e[2]||(e[2]=t("span",null,"协议标题",-1)),v(t("input",{"onUpdate:modelValue":e[0]||(e[0]=a=>s.value.title=a),class:"mobile-input",placeholder:"弦予音乐用户协议"},null,512),[[b,s.value.title]])]),t("label",U,[e[3]||(e[3]=t("span",null,"协议内容",-1)),v(t("textarea",{"onUpdate:modelValue":e[1]||(e[1]=a=>s.value.content=a),class:"mobile-textarea agreement-textarea",placeholder:"请输入用户协议内容"},null,512),[[b,s.value.content]])]),t("div",A,[t("button",{class:"mobile-btn",disabled:o.value,onClick:_},"恢复初版",8,B),t("button",{class:"mobile-btn primary",disabled:o.value,onClick:g},c(o.value?"保存中...":"保存协议"),9,S)])],64))]),t("section",V,[e[6]||(e[6]=t("h3",{class:"mobile-card-title"},"协议预览",-1)),t("div",F,c(s.value.title||"弦予音乐用户协议"),1),t("div",T,c(s.value.content),1)])]))}}),q=k(E,[["__scopeId","data-v-24e71252"]]);export{q as default};
